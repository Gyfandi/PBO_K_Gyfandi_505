package view;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.DataStore;
import model.Pemesanan;

import java.util.List;

public class AdminPanelView {
    private BorderPane root;


    public AdminPanelView(Stage stage) {
        root = new BorderPane();


        // ===== HEADER =====
        HBox header = new HBox();
        header.setStyle("-fx-background-color: #AEE2F8; -fx-padding: 20;");
        header.setAlignment(Pos.CENTER_LEFT);
        Label title = new Label("Konser Musik Theater");
        title.setFont(Font.font("Monospaced", FontWeight.BOLD, 28));
        header.getChildren().add(title);

        // ===== NAVBAR =====
        HBox navbar = new HBox(20);
        navbar.setStyle("-fx-background-color: #222; -fx-padding: 10;");
        navbar.setAlignment(Pos.CENTER_LEFT);
        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white;");
        logoutBtn.setOnAction(e -> stage.setScene(new Scene(new LoginView(stage).getView(), 900, 600)));
        navbar.getChildren().add(logoutBtn);

        // ===== SIDEBAR =====
        VBox sidebar = new VBox(15);
        sidebar.setPadding(new Insets(15));
        sidebar.setStyle("-fx-background-color: #eee;");
        Label menuAdminLabel = new Label("Menu Administrator");
        menuAdminLabel.setStyle("-fx-font-weight: bold; -fx-background-color: black; -fx-text-fill: white;");
        menuAdminLabel.setMaxWidth(Double.MAX_VALUE);
        menuAdminLabel.setAlignment(Pos.CENTER);

        Button kelolaJamBtn = new Button("KELOLA JAM");
        Button kelolaKategoriBtn = new Button("KELOLA KATEGORI MUSIK");
        Button kelolaPemesananBtn = new Button("KELOLA PEMESANAN");
        Button laporanPenjualanBtn = new Button("LAPORAN PENJUALAN");

        for (Button btn : new Button[]{kelolaJamBtn, kelolaKategoriBtn, kelolaPemesananBtn, laporanPenjualanBtn}) {
            btn.setMaxWidth(Double.MAX_VALUE);
            btn.setStyle(
                    "-fx-background-color: white; " +
                            "-fx-border-color: red; -fx-border-width: 2px; " +
                            "-fx-text-fill: red; -fx-font-weight: bold;"
            );
        }

        kelolaJamBtn.setOnAction(e -> {
            stage.setScene(new Scene(new JamView(stage).getView(), 900, 600));
        });

        kelolaKategoriBtn.setOnAction(e -> {
            stage.setScene(new Scene(new KategoriView(stage).getView(), 900, 600));
        });

        kelolaPemesananBtn.setOnAction(e -> {
            List<Pemesanan> semuaPemesanan = DataStore.getInstance().getPemesananList();
            stage.setScene(new Scene(new PemesananAdminView(stage, FXCollections.observableArrayList(semuaPemesanan)).getView(), 900, 600));
        });

        laporanPenjualanBtn.setOnAction(e -> {
            stage.setScene(new Scene(new LaporanPenjualanView(stage).getView(), 900, 600));
        });

        sidebar.getChildren().addAll(
                menuAdminLabel,
                kelolaJamBtn,
                kelolaKategoriBtn,
                kelolaPemesananBtn,
                laporanPenjualanBtn
        );

        // ===== MAIN CONTENT: Placeholder =====
        VBox content = new VBox(10);
        content.setPadding(new Insets(15));
        content.setStyle("-fx-background-color: #f4f4f4;");
        Label welcome = new Label("Selamat datang di Panel Administrator!");
        welcome.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        content.getChildren().add(welcome);

        // ===== Root Layout Composition =====
        VBox topContainer = new VBox(header, navbar);
        root.setTop(topContainer);
        root.setLeft(sidebar);
        root.setCenter(content);
    }

    public BorderPane getView() {
        return root;
    }
}
