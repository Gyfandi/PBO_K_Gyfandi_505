package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Pembayaran;
import model.Pemesanan;

import java.io.File;
import java.time.LocalDateTime;

public class PembayaranView {

    private VBox root;
    private ScrollPane scrollPane;

    public PembayaranView(Stage stage, Pemesanan pemesanan) {
        final boolean pembelianPertama = pemesanan.isPembelianPertama();

        root = new VBox(20);
        root.setPadding(new Insets(40));
        root.setAlignment(Pos.TOP_CENTER);
        root.setStyle("-fx-background-color: #E3F2FD;");

        scrollPane = new ScrollPane();
        scrollPane.setContent(root);
        scrollPane.setFitToWidth(true); // agar lebarnya penuh
        scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);

        Label lblTitle = new Label("Konfirmasi & Pembayaran Tiket");
        lblTitle.setFont(Font.font("Arial", FontWeight.BOLD, 22));

        GridPane detailGrid = new GridPane();
        detailGrid.setHgap(10);
        detailGrid.setVgap(10);
        detailGrid.setPadding(new Insets(15));
        detailGrid.setStyle("-fx-background-color: white; -fx-border-color: #90CAF9; -fx-border-width: 2;");
        detailGrid.setMaxWidth(450);

        detailGrid.add(new Label("Nama:"), 0, 0);
        detailGrid.add(new Label(pemesanan.getNama()), 1, 0);

        detailGrid.add(new Label("Email:"), 0, 1);
        detailGrid.add(new Label(pemesanan.getEmail()), 1, 1);

        detailGrid.add(new Label("No. Telepon:"), 0, 2);
        detailGrid.add(new Label(pemesanan.getTelp()), 1, 2);

        detailGrid.add(new Label("Judul Konser:"), 0, 3);
        detailGrid.add(new Label(pemesanan.getKonser().getJudul()), 1, 3);

        detailGrid.add(new Label("Tanggal:"), 0, 4);
        detailGrid.add(new Label(pemesanan.getKonser().getTanggal()), 1, 4);

        detailGrid.add(new Label("Jam:"), 0, 5);
        detailGrid.add(new Label(pemesanan.getJam()), 1, 5);

        detailGrid.add(new Label("Kursi:"), 0, 6);
        detailGrid.add(new Label(pemesanan.getKursi()), 1, 6);

        int hargaPerTiket = 100000;
        int jumlahKursi = pemesanan.getKursi().split(",").length;
        int totalHargaSebelumDiskon = hargaPerTiket * jumlahKursi;

        final int totalHarga;
        Label diskonLabel = new Label();

        if (pembelianPertama) {
            double diskon = 0.10;
            int potongan = (int) (totalHargaSebelumDiskon * diskon);
            totalHarga = totalHargaSebelumDiskon - potongan;
            diskonLabel.setText("Diskon Pembelian Pertama (10%): -Rp " + potongan);
            diskonLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
            diskonLabel.setTextFill(Color.FORESTGREEN);
        } else {
            totalHarga = totalHargaSebelumDiskon;
        }

        detailGrid.add(new Label("Harga per Tiket:"), 0, 7);
        detailGrid.add(new Label("Rp " + hargaPerTiket), 1, 7);

        detailGrid.add(new Label("Jumlah Kursi:"), 0, 8);
        detailGrid.add(new Label(String.valueOf(jumlahKursi)), 1, 8);

        detailGrid.add(new Label("Metode Pembayaran:"), 0, 9);
        detailGrid.add(new Label("Qiu-Rizzzz"), 1, 9);

        Label totalHargaLabel = new Label("Total Harga yang Harus Dibayar: Rp " + totalHarga);
        totalHargaLabel.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        totalHargaLabel.setTextFill(Color.DARKRED);

        // QR Code
        ImageView qrImage;
        try {
            Image qr = new Image(getClass().getResource("/assets/qr_dummy.png").toExternalForm());
            qrImage = new ImageView(qr);
        } catch (Exception e) {
            qrImage = new ImageView();
            System.out.println("QR code gagal dimuat: " + e.getMessage());
        }
        qrImage.setFitWidth(200);
        qrImage.setPreserveRatio(true);

        Label qrLabel = new Label("Scan QR Code untuk membayar dengan Qiu-Rizzzz");
        qrLabel.setFont(Font.font("Arial", FontWeight.SEMI_BOLD, 14));

        // Upload bukti pembayaran
        Label uploadLabel = new Label("Upload Bukti Pembayaran:");
        uploadLabel.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        Button uploadButton = new Button("Pilih Gambar");

        ImageView uploadedImageView = new ImageView();
        uploadedImageView.setFitWidth(200);
        uploadedImageView.setPreserveRatio(true);

        uploadButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Pilih Bukti Pembayaran");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg")
            );
            File file = fileChooser.showOpenDialog(stage);
            if (file != null) {
                uploadedImageView.setImage(new Image(file.toURI().toString()));
            }
        });

        // Tombol Bayar
        Button bayarBtn = new Button("Bayar Sekarang");
        bayarBtn.setStyle("-fx-background-color: #1976D2; -fx-text-fill: white; -fx-font-weight: bold;");
        bayarBtn.setOnAction(e -> {
            if (uploadedImageView.getImage() == null) {
                Alert peringatan = new Alert(Alert.AlertType.WARNING, "Harap upload bukti pembayaran terlebih dahulu!");
                peringatan.showAndWait();
                return;
            }

            Pembayaran pembayaran = new Pembayaran(
                    "PAY" + System.currentTimeMillis(),
                    "Qiu-Rizzzz",
                    totalHarga,
                    LocalDateTime.now(),
                    pembelianPertama
            );
            pembayaran.konfirmasiLunas();

            pemesanan.setPembelianPertama(false);

            Alert sukses = new Alert(Alert.AlertType.INFORMATION, "Pembayaran berhasil! Tiket Anda sedang diproses.");
            sukses.showAndWait();

            stage.setScene(new Scene(new TiketView(stage, pemesanan).getView(), 800, 600));
        });

        VBox uploadBox = new VBox(10, uploadLabel, uploadButton, uploadedImageView);
        uploadBox.setAlignment(Pos.CENTER);

        // Tambahkan ke root VBox
        root.getChildren().addAll(lblTitle, detailGrid);
        if (pembelianPertama) {
            root.getChildren().add(diskonLabel);
        }
        root.getChildren().addAll(totalHargaLabel, qrImage, qrLabel, uploadBox, bayarBtn);
    }

    public ScrollPane getView() {
        return scrollPane;
    }
}