package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import model.Pemesanan;

public class TiketCetakView {
    private StackPane root;
    private Stage stage;

    public TiketCetakView(Stage stage, Pemesanan pemesanan) {


        this.stage = stage;
        root = new StackPane();

        // Set background color to sky blue
        root.setBackground(new Background(new BackgroundFill(Color.SKYBLUE, CornerRadii.EMPTY, Insets.EMPTY)));

        // Kontainer isi tiket (tengah)
        VBox content = new VBox(10);
        content.setPadding(new Insets(20));
        content.setAlignment(Pos.CENTER);

        Label title = new Label("TIKET KONSER MUSIK");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        title.setStyle("-fx-underline: true;");
        title.setTextAlignment(TextAlignment.CENTER);

        VBox info = new VBox(10);
        info.setAlignment(Pos.CENTER);
        info.getChildren().addAll(
                buatBaris("Nama Pemesan", pemesanan.getNama()),
                buatBaris("No Telp", pemesanan.getTelp()),
                buatBaris("Judul Musik", pemesanan.getKonser().getJudul()),
                buatBaris("Tanggal & Jam Konser", pemesanan.getKonser().getTanggal() + ", " + pemesanan.getJam() + ":00"),
                buatBaris("Harga Tiket", "Rp " + pemesanan.getKonser().getHarga() + " / Tiket"),
                buatBaris("Kursi", "No. " + pemesanan.getKursi())
        );

        Label footer = new Label("Selamat Menikmati Konser Musik Kesayangan Anda..\nTiket Konser");
        footer.setFont(Font.font("Arial", 12));
        footer.setTextAlignment(TextAlignment.CENTER);

        content.getChildren().addAll(
                new Label("E - Tiket"),
                title,
                new Separator(),
                info,
                new Separator(),
                footer
        );

        // Tombol Kembali
        Button kembaliButton = new Button("Kembali");
        kembaliButton.setOnAction(e -> {
            // Arahkan kembali ke UserPanelView
            stage.setScene(new Scene(new UserPanelView(stage).getView(), 900, 600));
        });

        // Tombol Cetak
        Button cetakButton = new Button("CETAK TIKET");
        cetakButton.setStyle("-fx-background-color: white; -fx-border-color: black;");
        cetakButton.setOnAction(e -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Cetak Tiket");
            alert.setHeaderText(null);
            alert.setContentText("Tiket berhasil dicetak!");
            alert.showAndWait();
        });

        // Layout tombol kiri dan kanan
        BorderPane bottomPane = new BorderPane();
        bottomPane.setLeft(kembaliButton);
        bottomPane.setRight(cetakButton);
        bottomPane.setPadding(new Insets(10));

        // Layout utama
        BorderPane layout = new BorderPane();
        layout.setCenter(content);
        layout.setBottom(bottomPane);

        root.getChildren().add(layout);
    }

    private VBox buatBaris(String label, String isi) {
        Label l = new Label(label);
        l.setFont(Font.font("Arial", FontWeight.BOLD, 14));
        Label v = new Label(isi);
        v.setFont(Font.font("Arial", 14));
        l.setTextAlignment(TextAlignment.CENTER);
        v.setTextAlignment(TextAlignment.CENTER);

        VBox baris = new VBox(2, l, v);
        baris.setAlignment(Pos.CENTER);
        return baris;
    }

    public StackPane getView() {
        return root;
    }
}
