package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.Konser;
import model.Pemesanan;

public class UserPanelView {
    private BorderPane root;

    public UserPanelView(Stage stage) {
        this(stage, null, null);
    }

    public UserPanelView(Stage stage, Konser konser, Pemesanan pemesanan) {
        root = new BorderPane();

        // ===== HEADER =====
        HBox header = new HBox();
        header.setStyle("-fx-background-color: #AEE2F8; -fx-padding: 20;");
        header.setAlignment(Pos.CENTER_LEFT);
        Label title = new Label("Konser Musik Theater");
        title.setFont(Font.font("Monospaced", FontWeight.BOLD, 28));
        header.getChildren().add(title);

        // ===== NAVBAR: Logout di kiri =====
        HBox navbar = new HBox();
        navbar.setStyle("-fx-background-color: #222; -fx-padding: 10;");
        navbar.setAlignment(Pos.CENTER_LEFT);
        Button logoutBtn = new Button("Logout");
        logoutBtn.setStyle("-fx-background-color: transparent; -fx-text-fill: white;");
        logoutBtn.setOnAction(e -> stage.setScene(new Scene(new LoginView(stage).getView(), 900, 600)));
        navbar.getChildren().add(logoutBtn);

        // ===== SIDEBAR =====
        VBox sidebar = new VBox(15);
        sidebar.setPadding(new Insets(15));
        sidebar.setStyle("-fx-background-color: #eee;");
        sidebar.setPrefWidth(200);

        Label menuUserLabel = new Label("Menu Pengguna");
        menuUserLabel.setStyle("-fx-font-weight: bold; -fx-background-color: black; -fx-text-fill: white;");
        menuUserLabel.setMaxWidth(Double.MAX_VALUE);
        menuUserLabel.setAlignment(Pos.CENTER);

        Button detailTiketBtn = new Button("DETAIL TIKET");
        Button pesanBtn = new Button("PESAN TIKET");
        Button cetakBtn = new Button("CETAK TIKET");
        Button bayarBtn = new Button("PEMBAYARAN TIKET");
        Button kembaliList = new Button("Kembali ke List Tiket");

        for (Button btn : new Button[]{detailTiketBtn, pesanBtn, cetakBtn, bayarBtn, kembaliList}) {
            btn.setMaxWidth(Double.MAX_VALUE);
            btn.setStyle(
                    "-fx-background-color: white;" +
                            "-fx-border-color: #2196F3; -fx-border-width: 2px;" +
                            "-fx-text-fill: #2196F3; -fx-font-weight: bold;"
            );
        }

        // ===== Button Actions =====
        detailTiketBtn.setOnAction(e -> {
            if (pemesanan != null) {
                stage.setScene(new Scene(new TiketView(stage, pemesanan).getView(), 900, 600));
            } else {
                new Alert(Alert.AlertType.WARNING, "Belum ada pemesanan!").show();
            }
        });

        pesanBtn.setOnAction(e -> {
            if (konser != null) {
                stage.setScene(new Scene(new PemesananView(stage, konser).getView(), 900, 600));
            } else {
                new Alert(Alert.AlertType.WARNING, "Konser belum dipilih!").show();
            }
        });

        cetakBtn.setOnAction(e -> {
            if (pemesanan != null) {
                stage.setScene(new Scene(new TiketCetakView(stage, pemesanan).getView(), 900, 600));
            } else {
                new Alert(Alert.AlertType.WARNING, "Belum ada pemesanan!").show();
            }
        });

        bayarBtn.setOnAction(e -> {
            if (pemesanan != null) {
                stage.setScene(new Scene(new PembayaranView(stage, pemesanan).getView(), 900, 600));
            } else {
                new Alert(Alert.AlertType.WARNING, "Belum ada pemesanan!").show();
            }
        });

        kembaliList.setOnAction(e -> {
            stage.setScene(new Scene(new KonserListView(stage).getView(), 900, 600));
        });

        sidebar.getChildren().addAll(menuUserLabel, detailTiketBtn, pesanBtn, cetakBtn, bayarBtn, kembaliList);

        // ===== MAIN CONTENT =====
        VBox content = new VBox(10);
        content.setPadding(new Insets(15));
        content.setAlignment(Pos.TOP_LEFT);
        content.setStyle("-fx-background-color: #f4f4f4;");
        Label welcome = new Label("Selamat datang di halaman pengguna!");
        welcome.setFont(Font.font("Arial", 16));
        content.getChildren().add(welcome);

        // ===== Layout Composition =====
        VBox topContainer = new VBox(header, navbar);
        root.setTop(topContainer);
        root.setLeft(sidebar);
        root.setCenter(content);
    }

    public BorderPane getView() {
        return root;
    }
}
