package view;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import model.Konser;

import java.net.URL;

public class KonserListView {
    private Stage stage;

    public KonserListView(Stage stage) {
        this.stage = stage;
    }

    public BorderPane getView() {


        BorderPane root = new BorderPane();
        root.setPadding(new Insets(10));

        // Daftar konser (kiri)
        VBox daftarKonser = new VBox(20);
        daftarKonser.setPadding(new Insets(10));
        daftarKonser.setStyle("-fx-background-color: deepskyblue;");
        daftarKonser.setPrefWidth(690);
        daftarKonser.getChildren().addAll(
                buatItemKonser(new Konser("Sister Gem", "Rock", "120 menit", "/assets/Kak_Gem.jpg", "25 Juni 2025",250000)),
                buatItemKonser(new Konser("Angel Persik", "Dangdut", "120 menit", "/assets/Angel_Persik.jpg", "28 Juni 2025",250000))
        );

        // Panel login dan video (kanan)
        VBox sidePanel = new VBox(20);
        sidePanel.setPadding(new Insets(10));
        sidePanel.setPrefWidth(300);
        sidePanel.getChildren().addAll(buatTeaserBox());


        root.setLeft(daftarKonser);
        root.setRight(sidePanel);
        return root;
    }

    private Node buatItemKonser(Konser konser) {
        VBox box = new VBox(5);
        box.setPadding(new Insets(10));
        box.setStyle("-fx-background-color: white;");

        Label title = new Label(konser.getJudul());
        title.setFont(Font.font("Arial", 20));
        title.setStyle("-fx-font-weight: bold;");

        ImageView img;
        try {
            Image image = new Image(getClass().getResource(konser.getImagePath()).toExternalForm());
            img = new ImageView(image);
        } catch (Exception e) {
            img = new ImageView(new Image("https://via.placeholder.com/120"));
        }

        img.setFitWidth(120);
        img.setPreserveRatio(true);

        // Klik gambar → buka PemesananView
        img.setOnMouseClicked(e -> {
            PemesananView p = new PemesananView(stage, konser);
            stage.setScene(new Scene(p.getView(), 800, 600));
        });

        VBox info = new VBox(5);
        info.getChildren().addAll(
                new Label("Jenis Musik : " + konser.getGenre().toUpperCase()),
                new Label("Durasi : " + konser.getDurasi()),
                new Label("Tanggal : " + konser.getTanggal()) // tampilkan tanggal konser
        );

        HBox item = new HBox(10, img, info);
        box.getChildren().addAll(title, item);
        return box;
    }
    private Node buatTeaserBox() {
        VBox teaserBox = new VBox(10);
        teaserBox.setPadding(new Insets(10));
        teaserBox.setStyle("-fx-background-color: lightgray;");

        Label title = new Label("New Musik Teaser");
        title.setStyle("-fx-font-weight: bold;");
        Label subtitle = new Label("Sister Gem");
        subtitle.setTextFill(Color.RED);

        MediaView mediaView = new MediaView();
        URL videoUrl = getClass().getResource("/assets/Sister_Gem_Teaser.mp4");

        if (videoUrl != null) {
            try {
                Media media = new Media(videoUrl.toExternalForm());
                MediaPlayer mediaPlayer = new MediaPlayer(media);
                mediaView.setMediaPlayer(mediaPlayer);
                mediaView.setFitWidth(280);
                mediaView.setPreserveRatio(true);
                mediaPlayer.setAutoPlay(true);
            } catch (Exception e) {
                teaserBox.getChildren().add(new Label("Gagal memuat video."));
                System.out.println("Error loading video: " + e.getMessage());
            }
        } else {
            teaserBox.getChildren().add(new Label("Video teaser tidak ditemukan."));
            System.out.println("File video tidak ditemukan.");
        }

        teaserBox.getChildren().addAll(title, subtitle, mediaView);
        return teaserBox;
    }
}