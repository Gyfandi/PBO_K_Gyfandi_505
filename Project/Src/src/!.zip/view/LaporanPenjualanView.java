package view;

import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import model.Pemesanan;
import model.DataStore;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class LaporanPenjualanView {
    private VBox root;

    public LaporanPenjualanView(Stage stage) {


        root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.TOP_CENTER);

        Label title = new Label("Laporan Penjualan Tiket");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));

        // Ambil data pemesanan
        List<Pemesanan> semuaPemesanan = DataStore.getInstance().getPemesananList();

        // Hitung total penjualan berdasarkan konser
        Map<String, Long> penjualanPerKonser = semuaPemesanan.stream()
                .collect(Collectors.groupingBy(p -> p.getKonser().getJudul(), Collectors.counting()));

        TableView<Map.Entry<String, Long>> table = new TableView<>();

        TableColumn<Map.Entry<String, Long>, String> colJudul = new TableColumn<>("Judul Musik");
        colJudul.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getKey()));

        TableColumn<Map.Entry<String, Long>, String> colJumlah = new TableColumn<>("Jumlah Terjual");
        colJumlah.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getValue().toString()));

        table.getColumns().addAll(colJudul, colJumlah);
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setItems(FXCollections.observableArrayList(penjualanPerKonser.entrySet()));

        Button kembaliBtn = new Button("Kembali ke Menu Administrator");
        kembaliBtn.setOnAction(e -> stage.setScene(new Scene(new AdminPanelView(stage).getView(), 900, 600)));

        root.getChildren().addAll(title, table, kembaliBtn);
    }

    public VBox getView() {
        return root;
    }
}